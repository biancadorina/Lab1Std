Ex 2 -> Am aflat numarul de core-uri cu ajutorul functiei sysconf(_SC_NPROCESSORS_ONLN) -argumentul e pentru nr de core-uri (6 nuclee, daca nu specific nr de procese imi ia nr procese = nr core-uri si se afiseaza "Hello World" de 6 ori).
Ex 3 -> Daca rulez cu 3 procese - se afiseaza "Hello World" de 3 ori.
Ex 4 -> Pentru a rula cu 20 de procese am folosit mpirun -oversubscribe -n -20 ./2_numCores 
Ex 5 -> Am folosit un for cu 100 de iteratii si fiecare proces va face cele 100 de iteratii.
Ex 6 -> Am implementat functiile printHelloWorld() si  printSomethingElse() si primul proces executa prima functie si  celalalt pe cea de-a doua.
Ex 7 -> Verific cu un if rank-ul procesului pentru a vedea care e primul si care e ultimul.
Ex 8 -> Pentru rank-ul 0 initializez B cu 100 si pentru rank-ul 9 initializez cu 1000 (𝐴^𝑟𝑎𝑛𝑘 + 𝐵 pentru ultimul proces Hello World si val 1512.00 from 9/10 si pentru primul proces Hello World si val 101.00 from 0/10)