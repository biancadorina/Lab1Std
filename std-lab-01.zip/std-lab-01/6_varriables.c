#include <mpi.h>
#include <stdio.h>
#include <math.h>

int main(int argc, char **argv)
{
	int rank;
	int nProcesses;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &nProcesses);
	//printf("Hello World from %i/%i \n", rank, nProcesses);
	int A = 2;
	int B = 0;
	printf("Proc %i/%i si var %d\n" ,rank, nProcesses,B);
	if(rank == 0)
	{
		B = 100;
	}
	if(rank == 9)
	{
		B = 1000;
	}
	printf("Proc %i/%i si var %d\n" ,rank, nProcesses,B);
	printf("Hello World si val %.2f from %i/%i \n",pow(A,rank)+B ,rank, nProcesses);

	MPI_Finalize();
	return 0;
}