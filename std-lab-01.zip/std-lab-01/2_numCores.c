#include <mpi.h>
#include <stdio.h>
#include <sched.h>
#include <sys/sysinfo.h>
#include <unistd.h>


int main(int argc, char **argv)
{
	int rank;
	int nProcesses;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &nProcesses);
	printf("Hello World from %i/%i \n", rank, nProcesses);
	MPI_Finalize();

	long int ncores = sysconf(_SC_NPROCESSORS_ONLN);
    if (ncores < 0) {
        perror("sysconf");
        return 1;
    }
    printf("Numărul de nuclee este: %ld\n", ncores);

	return 0;
}